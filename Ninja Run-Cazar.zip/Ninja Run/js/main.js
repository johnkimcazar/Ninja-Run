
var mushroom;
var player;
var background;
var ninja;
var cursors;
var floor_1;
var floor_1_x;
var floor_1_y;
var timer;

var mainState = {
	init: function() {
		this.game.physics.startSystem(Phaser.Physics.ARCADE);
		this.game.physics.arcade.gravity.y = 1000;
	},
	preload: function(){

		game.load.image('mushroom','assets/images/mushroom.png');
		game.load.image('player','assets/images/player.jpg');
		game.load.image('background', 'assets/images/BG.png');
		game.load.image('floor_1.1', 'assets/images/1.png');
		game.load.image('floor_1.2', 'assets/images/2.png');
		game.load.image('floor_1.3', 'assets/images/3.png');
		game.load.spritesheet('ninja-run', 'assets/images/ninja.png', 107.2,99);

	},
	create: function(){
		
		//var test = game.add.sprite(200,200,'mushroom');
		this.game.stage.scale.pageAlignHorizontally = true;
		this.game.stage.scale.pageAlignVertically = true;
		// this.game.stage.scale.refresh();
		//game.stage.backgroundColor = "#99bbff";
		// background = game.add.tileSprite(0,0,window.innerWidth/4+200, window.innerHeight,'background');
		this.background = this.game.add.tileSprite(0,0,1890, 700,'background');
		// background.height = game.height;
  //   	background.width = game.width;
    	//background.scale.setTo(1,1);
		//mushroom = game.add.sprite(game.world.centerX+125, game.world.centerY, 'mushroom'); 
		//player = game.add.sprite(game.world.centerX, game.world.centerY, 'player');
		this.floor_1 = game.add.group();
		floor_1_x = 500;
		floor_1_y = 525;

		this.initFloor();

		this.ninja = game.add.sprite(game.world.centerX, game.world.centerY, 'ninja-run');
		this.game.physics.arcade.enable(this.ninja);
		this.ninja.animations.add('jump', [0,1,2,3,4,5,6,7,8,9], 10,true);
		this.ninja.animations.add('run', [10,11,12,13,14,15,16,17,18,19], 10,true);
		this.ninja.animations.add('idle', [20,21,22,23,24,25,26,27,28,29], 10,true);
		this.ninja.animations.add('attack', [30,31,32,33,34,35,36,37,38,39], 10,true);
		this.ninja.animations.play('idle');

		game.debug.body(this.ninja);
		//game.debug.body(this.ninja);
		//setFloor_1Pos(this.floor_1,floor_1_x,floor_1_y);
		//initFloor_1(this.floor_1);
		//addRowOfFloor();


		//player.anchor.setTo(0.5,0.5);
		//mushroom.anchor.setTo(0.5,0.5);
		this.ninja.anchor.setTo(0.5, 0.5);
		console.log("1");
		this.timer = game.time.events.loop(2000, this.addRowOfFloor, this);
		console.log("2");
		this.game.physics.arcade.collide(this.player, this.floor_1);
		//player.scale.setTo(0.1);
		//mushroom.scale.setTo(0.1);
		//ninja.scale.setTo(0.9);
		this.score = 0;
		this.labelScore = game.add.text(game.world.centerX, 20, "0", 
    		{ font: "100px Arial", fill: "#ffffff" });  
    	

		this.labelHighScore2 = game.add.text(20, 20, "0", 
    		{ font: "30px Arial", fill: "#ffffff" });
		this.labelHighScore2.text = "High Score: ";
		this.labelHighScore = game.add.text(200, 20, "0", 
    		{ font: "30px Arial", fill: "#ffffff" });
    	this.labelHighScore.text =  window.localStorage.getItem( 'score' );
		//console.log(window.innerHeight);
	},
	update: function(){
		if(this.ninja.y>=525){
			if(this.score >= parseInt(window.localStorage.getItem( 'score' ))){
				this.labelHighScore.text = this.score;
				window.localStorage.setItem('score',this.labelHighScore.text);
			}
			
			this.gameRestart();
		}
		if (game.input.keyboard.isDown(Phaser.Keyboard.LEFT))
	    {
	        this.ninja.x-=10;
	    }
	    else if (game.input.keyboard.isDown(Phaser.Keyboard.RIGHT))
	    {
	        this.ninja.animations.play('run');
	        //this.ninja.body.moveRight(150);
	        this.ninja.x+=10;
	    } else
	    if (game.input.keyboard.isDown(Phaser.Keyboard.UP))
	    {
	       this.ninja.animations.play('jump');
	       this.ninja.y-=10;
	    }
	    else if (game.input.keyboard.isDown(Phaser.Keyboard.DOWN))
	    {
	        
	    }
	    else{
	    	this.ninja.animations.play('run');
	    	this.ninja.x+=3;
	    }
	    this.game.physics.arcade.collide(this.ninja, this.floor_1);
	    //this.timer = game.time.events.loop(1500, this.addRowOfFloor, this); 
	    //addRowOfFloor();
	    // this.game.physics.arcade.collide(this.ninja, this.floor_1.children[0]);
	    // this.game.physics.arcade.collide(this.ninja, this.floor_1.children[1]);
	    // this.game.physics.arcade.collide(this.ninja, this.floor_1.children[2]);
	},
	addOneFloor: function (x,y) {
	   
	    var floor = game.add.sprite(x, y, 'floor_1.2');

	  
	    this.floor_1.add(floor);

	    game.physics.arcade.enable(floor);

	
	    floor.body.velocity.x = -200;
	    floor.body.allowGravity = false;
	    floor.body.immovable = true;

	    floor.checkWorldBounds = true;
	},
	addRowOfFloor: function () {
		this.score += 1;
		this.labelScore.text = this.score; 
	    var hole = Math.floor(Math.random() * 2) + 1;

	  
	    for (var i = 0; i < 3; i++){
	    	if (i != hole && i != hole + 1) 
	    	this.addOneFloor(1350+i*128, 525);   
	    }
	},
	initFloor: function (){
		//console.log("hj");
		var hole = Math.floor(Math.random() * 2) + 1;

	    for (var i = 0; i < 10; i++){
	    	if (i != hole && i != hole + 1) 
	    	this.addOneFloor(i*128, 525);   
	    }
	},
	gameRestart: function() {
    	this.game.state.start('mainState');
	},
};

// var game = new Phaser.Game(window.innerWidth/4+200, window.innerHeight, Phaser.AUTO);
var game = new Phaser.Game(1350, 647, Phaser.AUTO,'game');

game.state.add('mainState', mainState);
game.state.start('mainState');

// function setFloor_1Pos(floor_1,x,y){
// 	for(var i = 0; i < 3; i++)
// 		{
// 			if(i == 0){
// 				floor_1.create(x,y,'floor_1.1');
// 			}
// 			else
// 			if (i == 1){
// 				floor_1.create(x+128,y,'floor_1.2');
// 			}
// 			else
// 			if (i == 2){
// 				floor_1.create(x+128*2,y,'floor_1.3');
// 			}
// 			this.game.physics.arcade.enable(floor_1.children[i]);

// 		}
// }
// function initFloor_1(floor_1){
	
// 	//this.<group_name>.children[i]

// 	for(var i = 0; i < 3; i++)
// 		{
			
// 			floor_1.children[i].body.allowGravity = false;
// 			floor_1.children[i].body.velocity.x = -200;
// 			//pipe.body.velocity.x = -200; 

// 		}
// }

	
// addOnePipe: function(x, y) {
//     // Create a pipe at the position x and y
//     var pipe = game.add.sprite(x, y, 'pipe');

//     // Add the pipe to our previously created group
//     this.pipes.add(pipe);

//     // Enable physics on the pipe 
//     game.physics.arcade.enable(pipe);

//     // Add velocity to the pipe to make it move left
//     pipe.body.velocity.x = -200; 

//     // Automatically kill the pipe when it's no longer visible 
//     pipe.checkWorldBounds = true;
//     pipe.outOfBoundsKill = true;
// },

	
